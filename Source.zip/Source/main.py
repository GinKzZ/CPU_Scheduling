from Function import solve

def main():
	solve()

if __name__ == "__main__":
	main()